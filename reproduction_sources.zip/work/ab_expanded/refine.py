from pathlib import Path
import sys,collections
root=Path.cwd();sys.path.insert(0,str(root/'work/milily'));from common import *
for species,folder in [('MiCucumber','micucumber_terminal'),('MiLily','milily'),('MiUrchin','miurchin_enddesign')]:
 p=root/'work'/folder;scratch=root/'work/ab_expanded'/species;pool=json.loads((scratch/'feasible.json').read_text());old=json.loads((scratch/'before_selected.json').read_text());panel=json.loads((root/'work/miurchin_mifish/panel.json').read_text()) if species=='MiUrchin' else read(p/'panel.csv');weights=np.array([float(x['weight']) if not(species=='MiCucumber' and x['order']=='Apodida') else 0 for x in panel]);weights/=weights.sum();wm=collections.defaultdict(int)
 for i,wgt in enumerate(weights):wm[float(wgt)]|=1<<i
 def bits(v):return sum(1<<i for i,x in enumerate(v) if x)
 def score(v):return sum(wgt*(v&mask).bit_count() for wgt,mask in wm.items())
 chosen=[];audit=[]
 for reg in ['S','M','L','XL']:
  original=[x for x in old if x['name'] in [reg+'A',reg+'B']];bc=score(bits(original[0]['cv'])|bits(original[1]['cv']));be=score(bits(original[0]['ex'])|bits(original[1]['ex']));g=[x for x in pool if x['region']==reg];unique={}
  for x in g:unique.setdefault((x['_cv'],x['_ex'],tuple(x['WC3']),tuple(x['GT2'])),x)
  best=None
  for a,b in itertools.combinations(unique.values(),2):
   wc=set(a['WC3'])|set(b['WC3']);gt=set(a['GT2'])|set(b['GT2'])
   if len(wc)>5 or len(gt)>5:continue
   c=score(a['_cv']|b['_cv']);e=score(a['_ex']|b['_ex'])
   if c+1e-9<bc or e+1e-9<be:continue
   au=score(a['_cv']&~b['_cv'])+score(a['_ex']&~b['_ex']);bu=score(b['_cv']&~a['_cv'])+score(b['_ex']&~a['_ex']);key=(int(min(au,bu)>1e-9),round(c+e,12),round(min(au,bu),12),-len(wc)-len(gt))
   if best is None or key>best:best=key;pair=(a,b);met=(c,e,au,bu)
  if best is None:raise RuntimeError((species,reg,'no nondeteriorating option'))
  c,e,au,bu=met
  for i,x in enumerate(pair):chosen.append(dict(x,name=reg+chr(65+i),scheme=reg+'A+'+reg+'B',chemistry='ordinary',option=2,source='terminal_adjustment',thermal=thermal(x['F'],x['R'])[1],union_coverage=c,union_exact=e))
  audit.append(dict(project=species,region=reg,feasible_pairs=len(g),distinct_states=len(unique),previous_coverage=100*bc,previous_exact=100*be,coverage_pct=100*c,exact_pct=100*e,A_unique_combined=100*au,B_unique_combined=100*bu,recommended=min(au,bu)>1e-9));print(audit[-1],flush=True)
 (scratch/'selected.json').write_text(json.dumps(chosen,indent=2));write(root/'outputs'/f'{species}_AB_expanded/search_audit.csv',audit)
