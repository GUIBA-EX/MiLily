from pathlib import Path
import json,shutil
root=Path.cwd()
for species,folder,sel,olname in [('MiCucumber','micucumber_terminal','selected.json','combined_oligos.json'),('MiLily','milily','selected.json','oligos.json'),('MiUrchin','miurchin_enddesign','selected_strict.json','extended_oligos.json')]:
 p=root/'work'/folder;scratch=root/'work/ab_expanded'/species;old=json.loads((scratch/'before_selected.json').read_text());new={x['name']:x for x in json.loads((scratch/'selected.json').read_text())};rr=[new.get(x['name'],x) for x in old]
 for a,b in zip(old,rr):
  if not a['name'].endswith(('A','B')):assert a==b
 ols=json.loads((scratch/'before_oligos.json').read_text());used={r[side+'_id'] for r in new.values() for side in ['F','R']};ols+=[x for x in json.loads((scratch/'oligos.json').read_text()) if x['id'] in used];(p/olname).write_text(json.dumps(ols));
 if species=='MiLily':
  spans={x['region']:x['reference_span'] for x in old}
  for x in rr:x['reference_span']=spans[x['region']]
 (p/sel).write_text(json.dumps(rr,indent=2))
