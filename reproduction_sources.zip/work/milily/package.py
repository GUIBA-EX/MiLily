from common import *
import shutil,zipfile,hashlib,html,collections
out=root/'outputs/MiLily';out.mkdir(exist_ok=True)
for d in ['results','figures','sequences','references','scripts','docs']:(out/d).mkdir(exist_ok=True)
for f in (p/'release').iterdir():shutil.copy2(f,out/'results'/f.name)
for f in (p/'release').glob('*.svg'):shutil.copy2(f,out/'figures'/f.name)
for n in ['primer_pairs.csv','primers.fasta']:shutil.copy2(p/'release'/n,out/'sequences'/n)
for n in ['target.fasta','background.fasta','metadata.tsv','full_length.fasta','full_aligned.fasta','target_aligned.fasta','panel.csv','input_manifest.json','config.json']:shutil.copy2(p/n,out/'references'/n)
for n in ['selected.json','audit.json','oligos.json']:shutil.copy2(p/n,out/'results'/n)
for n in ['independent_hits.tsv','target_barcodes.tsv']:shutil.copy2(p/'verify'/n,out/'results'/n)
shutil.copy2(p/'PLAN.md',out/'docs/METHODS.md')
(out/'requirements.txt').write_text('numpy==2.4.6\nbiopython==1.87\nprimer3-py==2.4.0\n')
comp=read(p/'release/comparison.csv');rr=json.loads((p/'selected.json').read_text());positions=read(p/'release/binding_positions.csv')
for zh in [False,True]:
 title='海百合纲线粒体16S引物 · 首轮计算设计' if zh else 'Crinoid mitochondrial 16S primers · First computational trial'
 s=f'# MiLily\n\n{title}\n\n'+('[English](README.md)' if zh else '[简体中文](README.zh-CN.md)')+'\n\n![MiLily binding positions](figures/binding_positions.svg)\n\n'
 s+=('沿用MiCucumber／MiUrchin方法，比较S、M、L、XL四档长度的普通与简并方案。D为简并单对；无后缀为普通单对，A/B为两次独立PCR的普通引物组件。共12套方案、16对记录、32条寡核苷酸。A/B前向和反向起点差均限制在35 bp内；不同备选方案仍可能位于不同区域，长度代号不代表相同位点。\n\n' if zh else 'Following the MiCucumber/MiUrchin workflow, four reference-length bands compare degenerate and ordinary designs. D marks one degenerate pair; an unsuffixed name marks one ordinary pair; A/B are ordinary components used in separate PCRs. There are 12 portfolios, 16 paired records and 32 oligos. Both forward and reverse starts of A/B components differ by at most 35 bp. Alternative portfolios can use different loci; length labels do not imply identical sites.\n\n')
 s+=('## 首轮选择\n\n优先比较 **SD（短片段、较高完全匹配）**、**MD（最高简并单对覆盖）**、**LD（中等长度兼顾覆盖与完全匹配）**。若优先减少寡核苷酸种类，普通 **L单对**可作为重点候选：覆盖率88%、完全匹配率30%，WC≤3、GT≤2及WC≤4背景命中均为0。增加LA/LB只将完全匹配率提升到38%，未增加覆盖。XLD完全匹配率62%，但WC≤4背景命中104条，须单独评估。以上均为计算筛选结果，尚未做PCR实测。\n\n' if zh else '## First-trial priorities\n\nPrioritize **SD** for a short amplicon with relatively high exact matching, **MD** for maximal degenerate single-pair coverage, and **LD** for intermediate length and balanced coverage/exact matching. For fewer oligo variants, ordinary **L** is a strong candidate: 88% coverage, 30% exact matching, and zero WC≤3, GT≤2 and WC≤4 background hits. LA/LB raises exact matching to 38% without improving coverage. XLD reaches 62% exact matching but has 104 WC≤4 background hits. These are computational candidates without wet-lab validation.\n\n')
 s+=('## 共同完整序列面板\n\n27个标签内去重的完整序列、25个分类名称标签（包含未定种，不等于25个已确认物种）。标签等权，标签内单倍型等权。覆盖要求每条引物≤2个错配且末端3位IUPAC相容；完全匹配要求两条引物均零错配。\n\n' if zh else '## Shared complete-sequence panel\n\n27 full-sequence haplotypes deduplicated within 25 taxonomic labels, including unresolved identifications; these are not 25 confirmed species. Labels and within-label haplotypes receive equal weights. Coverage requires ≤2 mismatches per primer and IUPAC-compatible terminal 3 nt; exact matching requires zero mismatches on both primers.\n\n')
 s+='| Scheme | Coverage | Exact | WC≤3 | GT≤2 | WC≤4 | Observed product bp |\n|---|---:|---:|---:|---:|---:|---|\n'
 for r in comp:s+=f"| {r['scheme']} | {float(r['coverage_pct']):.1f}% | {float(r['exact_pct']):.1f}% | {r['WC3']} | {r['GT2']} | {r['WC4']} | {r['product_min']}–{r['product_max']} |\n"
 s+='\n'+('背景为7,177条冻结记录；背景数字是命中的accession数，不是扩增概率。GT模型允许可能的G–T配对；WC≤4为更宽松的敏感性分析。两对结果为独立PCR并集，未验证混合多重PCR。\n\n' if zh else 'Background counts are accessions among 7,177 frozen records, not probabilities of amplification. GT permits possible G–T pairing; WC≤4 is a more permissive sensitivity analysis. Two-pair metrics are separate-PCR unions, not validated multiplex performance.\n\n')
 s+=('## 参考数据与局限\n\n使用已有MiStar／MiCucumber冻结数据库的269条海百合纲16S记录，未进行本轮全面更新。参考坐标为*Florometra serratissima* AF049132.1提取的16S，1-based、无gap。S/M/L/XL参考跨度分别为150–224、225–284、285–359、360–450 bp，包含引物；实际类群长度可以超出分档。\n\n多数短片段不跨越候选位点：除XLA/XLB外，各方案仅43条记录、25个标签可评估；它们含完整序列的重复记录，去重后的加权结果与完整面板相同。XLA/XLB可评估95条、66个标签，覆盖84.09%、完全匹配26.52%。不同方案可评估集合不同，不作直接排名。位点未覆盖标为不可评估，不直接计为漏检。设计面板同时用于选择和评价，结果不是独立留出测试；本轮搜索为有限位置与长度网格及空间分箱候选集，不保证全局最优。\n\n' if zh else '## Reference scope and limits\n\nThe existing frozen MiStar/MiCucumber corpus supplies 269 crinoid 16S records; no exhaustive refresh was performed. Coordinates use extracted 16S of *Florometra serratissima* AF049132.1, 1-based and ungapped. Reference spans are S150–224, M225–284, L285–359 and XL360–450 bp including primers; taxon-specific products may fall outside these bands.\n\nMost partial records do not span selected sites. Except XLA/XLB, portfolios have 43 evaluable records representing 25 labels; these include full-sequence duplicates, and deduplicated weighted metrics match the complete panel. XLA/XLB has 95 evaluable records / 66 labels, with 84.09% coverage and 26.52% exact matching. Evaluable sets differ and are not directly ranked. Missing site coverage is marked unevaluable, not a demonstrated failure. Selection and evaluation share the design panel: this is not a held-out test. The bounded coordinate/length grid and spatial shortlist do not guarantee a global optimum.\n\n')
 s+=('## 末端与热力学\n\n允许3′端简并，包括最后一位。逐一检查所有实际变体：无末端三连同碱基，末端3位至少1个G/C、末端5位1–4个G/C，全序列连续同碱基不超过4。使用50 nM/变体和200 nM/方向平均分配两种浓度；50 mM单价盐、1.5 mM Mg、0.6 mM dNTP。两种情景的所有发卡和二聚体Tm均低于55°C，F/R Tm区间中点差≤5°C；不等浓度异二聚体按较高一方浓度近似。\n\n' if zh else '## Terminal and thermodynamic rules\n\n3′ degeneracy is allowed, including the final base. Every concrete variant has no terminal homotriplet, ≥1 G/C in the last 3 nt, 1–4 G/C in the last 5 nt and no homopolymer longer than 4. Two scenarios use 50 nM per variant and 200 nM per direction equally divided among variants, with 50 mM monovalent salt, 1.5 mM Mg and 0.6 mM dNTP. All hairpin/dimer Tm values are <55°C and F/R Tm-range midpoint difference is ≤5°C. Unequal-concentration heterodimers use the larger partner concentration as an approximation.\n\n')
 s+=('## 序列、图件与复现\n\n' if zh else '## Sequences, figures and reproduction\n\n')
 s+='[Paired sequences](sequences/primer_pairs.csv) · [FASTA](sequences/primers.fasta) · [Full comparison](results/comparison.csv) · [Missed panel references](results/missed_references.csv) · [Target evaluation](results/target_evaluation.csv) · [Background accessions](results/background_hits.csv) · [Observed barcode resolution](results/barcode_resolution.csv)\n\n[All base-matching figures](results/base_matching.html) · [Coordinates](results/binding_positions.csv) · [Terminal audit](results/terminal_audit.csv) · [Thermodynamics](results/thermal.csv) · [Independent verification](results/verification.json) · [Methods](docs/METHODS.md) · [Reproduction](docs/REPRODUCIBILITY.md)\n\n'
 s+=('碱基匹配图按引物5′→3′方向显示全部27个完整序列；蓝色为IUPAC相容，橙色为错配，框选末端3位。问号表示长度不一致窗口。条形码分辨率仅描述当前被检出标签之间是否共享完全相同的内部序列，不代表真实物种鉴定准确率。\n\n' if zh else 'Base plots show all 27 complete sequences oriented as the primer, 5′→3′. Blue marks IUPAC compatibility, orange a mismatch, and the box terminal 3 nt. Question marks indicate unequal-length windows. Barcode resolution describes observed sharing of identical internal sequences among detected labels, not true species identification accuracy.\n\n')
 for reg in ['S','M','L','XL']:s+=f'### {reg}\n\n![MiLily {reg}D](figures/base_matching_{reg}D.svg)\n\n[Ordinary {reg}](figures/base_matching_{reg}.svg) · [{reg}A](figures/base_matching_{reg}A.svg) · [{reg}B](figures/base_matching_{reg}B.svg)\n\n'
 s+=('独立全序列扫描复核：864项目标状态、32项背景集合比较均无差异。详见复核记录。\n\n' if zh else 'Independent whole-sequence scans: all 864 target-state and 32 background-set comparisons agree. See the verification record.\n\n')
 s+='[Copyright / 著作权声明](COPYRIGHT.md)\n'
 (out/('README.zh-CN.md' if zh else 'README.md')).write_text(s)
(out/'docs/REPRODUCIBILITY.md').write_text('''# Reproduction / 复现

Extract `reproduction_sources.zip` into a fresh folder. Install Python 3.12 requirements, MAFFT 7 and a C++17 compiler. Candidate selection can be replayed from the frozen background-site file and oligo list:

```sh
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 python work/milily/optimize.py
c++ -O3 -std=c++17 work/micucumber_nondegenerate/independent_scan.cpp -o work/micucumber_nondegenerate/independent_scan
python work/milily/verify.py
python work/milily/summarize.py
python work/milily/extra_audit.py
python work/milily/figures.py
```

Results are written to `work/milily/release`. To repeat upstream discovery, run `discover.py`, compile `scan_sites.cpp`, then run the scanner with `work/milily/sites` as its argument before optimization. All supplied input FASTAs are frozen; no network retrieval is needed. Source inputs, weights and search constraints are described in METHODS.md.

解包后从冻结候选与背景位点重算选择，随后进行独立全序列扫描、末端检查与图件生成。`prepare.py`保留原始提取逻辑及来源路径，仅供追溯；复现直接使用随包提供的FASTA，不依赖原项目目录。
''')
(out/'docs/SOURCES.md').write_text('''# Source context

- Frozen accession provenance and extraction annotations: `references/metadata.tsv` and `references/input_manifest.json`.
- MiFish methodological reference: Miya et al. 2015, https://doi.org/10.1098/rsos.150088 . Transfer of the conservation/specificity and short-amplicon design approach, not a claim that fish 12S primers work in crinoid 16S.
- Crinoid 16S usage: https://pmc.ncbi.nlm.nih.gov/articles/PMC12179643/ . Molecular taxonomic study using mitochondrial 16S, COI and nuclear 28S; it does not validate these MiLily primers.
- Mitogenome context: https://pmc.ncbi.nlm.nih.gov/articles/PMC10478607/ . Poliometra prolixa mitochondrial genome with 16S annotation.
''')
# User-requested reuse restrictions apply to original project work; public sequence rights remain with their providers.
(out/'COPYRIGHT.md').write_text('''# Copyright / 著作权声明

Copyright © 2026 GUIBA-EX. All rights reserved for original MiLily project text, code and graphics. No reproduction, redistribution or adaptation without prior permission from the rights holder. Public reference sequences and third-party source material retain their original rights and terms.

MiLily原创项目文字、代码及图件保留全部权利。未经权利人许可，不得转载、分发或改编。公共参考序列及第三方资料遵循其原有权利和使用条款。
''')
with zipfile.ZipFile(out/'reproduction_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['common.py','prepare.py','discover.py','optimize.py','verify.py','summarize.py','extra_audit.py','figures.py','oligos.json','panel.csv','config.json','target.fasta','background.fasta','full_aligned.fasta','target_aligned.fasta','metadata.tsv','sites/background_sites.tsv']:
  z.write(p/n,'work/milily/'+n)
 z.write(root/'work/micucumber_terminal/scan_sites.cpp','work/milily/scan_sites.cpp');z.write(root/'work/micucumber_nondegenerate/independent_scan.cpp','work/micucumber_nondegenerate/independent_scan.cpp');z.write(out/'requirements.txt','requirements.txt')
for f in p.glob('*.py'):shutil.copy2(f,out/'scripts'/f.name)
(out/'report.html').write_text('<!doctype html><meta charset="utf-8"><title>MiLily</title><body style="font-family:Arial;margin:32px;background:#f7fbff;color:#173647"><h1>MiLily · 海百合16S引物</h1><p>首轮计算设计 / First computational trial</p><p><a href="README.zh-CN.md">中文README</a> · <a href="README.md">English README</a> · <a href="results/base_matching.html">完整碱基匹配图</a></p><img style="width:100%;max-width:1500px" src="figures/binding_positions.svg"><table border="1" cellpadding="10"><tr><th>Scheme</th><th>Coverage</th><th>Exact</th><th>WC3 / GT2 / WC4</th></tr>'+''.join(f"<tr><td>{r['scheme']}</td><td>{float(r['coverage_pct']):.1f}%</td><td>{float(r['exact_pct']):.1f}%</td><td>{r['WC3']} / {r['GT2']} / {r['WC4']}</td></tr>" for r in comp)+'</table><p>27 complete haplotypes / 25 labels; same design and evaluation panel. 864 target + 32 background checks agree. Not wet-lab validated.</p>')
print(out)
