# XS in the frozen source bundle

From the extracted bundle root:

```sh
python work/milily_xs/verify_xs.py --references work/milily --expected work/milily_xs/assessment.json --output /tmp/milily-xs-check
python work/milily_xs/xs_thermodynamics.py --output /tmp/milily-xs-thermal.json
```

The first command needs a C++17 compiler and Python standard library; the second needs the pinned primer3-py dependency. S–XL remain frozen separately in work/milily/selected.json.
